This archive includes Russian localization files for mods
The Terror From The Void - https://github.com/Voland163/TFTV
Officer class - https://github.com/LucusTheDestroyer/PhoenixPoint-Officer-Class/releases
of a computer game Phoenix Point from the Snapshot Games studio.

INSTALLATION
-for the STEAM version of the game you need to copy the contents of each (or one of) folders to the corresponding mod folder in "steam\steamapps\workshop"
-for other versions of the game (for example GOG), you need to unpack the archive into the root folder of the game, or, if you need to install the localization of only one of the mods, unpack only the corresponding subfolder into the Mods folder of the root directory of the game.

=======================================================================================================================================================================================================================================================

Этот архив включает в себя файлы русской локализации модов
The Terror From The Void - https://github.com/Voland163/TFTV
Officer class - https://github.com/LucusTheDestroyer/PhoenixPoint-Officer-Class/releases
компьютерной игры Phoenix Point  от студии Snapshot Games.

УСТАНОВКА
-для STEAM версии игры необходимо содержимое каждой из (или одной из) папок скопировать в папку соответствующего мода в "steam\steamapps\workshop"
-для других версий игры (например GOG) необходимо распаковать архив в корневую папку игры, или, если нужно установить локализацию только одного из модов - распаковать только соответствующую подпапку в папку Mods корневой директории игры.